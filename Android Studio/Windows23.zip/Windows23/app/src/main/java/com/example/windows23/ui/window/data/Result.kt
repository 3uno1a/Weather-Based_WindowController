package com.example.windows23.ui.window.data

import com.google.gson.annotations.SerializedName

data class ODUltraFineDust(       // 실외 초미세먼지 데이터
    @SerializedName("id")
    val place: String,
    @SerializedName("value")
    val value: Double,
    @SerializedName("date")
    val date: String
)

data class IDUltraFineDust(       // 실내 초미세먼지 데이터
    @SerializedName("id")
    val place: String,
    @SerializedName("value")
    val value: Double,
    @SerializedName("date")
    val date: String
)

data class Temp(             // 온도
    @SerializedName("id")
    val place: String,
    @SerializedName("value")
    val value: Double,
    @SerializedName("date")
    val date: String
)

data class RainStatus(         // 강우 상태
    @SerializedName("rainstatus")
    val control: Boolean
)

data class WindowStatus(       // 창문 개폐 상태
    @SerializedName("windowstatus")
    val control: Boolean
)

data class SttResult(
    @SerializedName("id")
    val id: Int,
    @SerializedName("text")
    val text: String,
    @SerializedName("date")
    val date: String
)

