package com.example.windows23.ui.window

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.windows23.ui.window.data.IDUltraFineDustResponse
import com.example.windows23.ui.window.data.ODUltraFineDustResponse
import com.example.windows23.ui.window.data.RainStatusResponse
import com.example.windows23.ui.window.data.SttResult
import com.example.windows23.ui.window.data.Temperature
import com.example.windows23.ui.window.data.WindowStatus
import com.example.windows23.ui.window.data.WindowStatusResponse
import com.example.windows23.ui.window.service.WINDOW
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class WindowViewModel : ViewModel() {
    private var latestInDust: MutableLiveData<String> = MutableLiveData()
    private var latestOutDust: MutableLiveData<String> = MutableLiveData()
    private var latestTemp: MutableLiveData<String> = MutableLiveData()    // 최신 온도값 저장하는 라이브 데이터, 값이 변경될 때마다 UI에 알림 제공
    private var isRaining: MutableLiveData<Boolean> = MutableLiveData()
    private var isWindowOpen: MutableLiveData<Boolean> = MutableLiveData()

    fun getLatestInDust(): LiveData<String> {
        return latestInDust
    }

    fun getLatestOutDust(): LiveData<String> {
        return latestOutDust
    }

    fun getLatestTemp(): LiveData<String> {    // 최신 온도값을 반환
        return latestTemp
    }

    fun getRainStatus(): LiveData<Boolean> {    // 실시간 데이터 받는 함수
        return isRaining
    }

    fun getWindowStatus(): LiveData<Boolean> {
        return isWindowOpen
    }

    fun loadLatestOutDust() {
        val outDustStatus = WINDOW.service.requestODUltraFine(page=1)

        outDustStatus.enqueue(object : Callback<ODUltraFineDustResponse> {
            override fun onResponse(call: Call<ODUltraFineDustResponse>, response: Response<ODUltraFineDustResponse>) {
                if (response.isSuccessful) {
                    val outDustData = response.body()
                    outDustData?.let { data ->
                        data.results.firstOrNull()?.let { result ->
                            latestOutDust.value = result.value.toString()
                        } ?: run {
                            latestOutDust.value = "실외 초미세먼지 데이터 수신 중"
                        }
                    }
                } else {
                    latestOutDust.value = "서버 응답 실패: ${response.code()}"
                }
            }
            override fun onFailure(call: Call<ODUltraFineDustResponse>, t: Throwable) {    // 서버 요청 실패
                latestOutDust.value = "Network Error"
                Log.e("windowViewModel", "")
            }
        })
    }

    fun loadLatestInDust() {
        val inDustStatus = WINDOW.service.requestIDUltraFine(page=1)

        inDustStatus.enqueue(object : Callback<IDUltraFineDustResponse> {
            override fun onResponse(call: Call<IDUltraFineDustResponse>, response: Response<IDUltraFineDustResponse>) {
                if (response.isSuccessful) {
                    val inDustData = response.body()
                    inDustData?.let { data ->
                        data.results.firstOrNull()?.let { result ->
                            latestInDust.value = result.value.toString()
                        } ?: run {
                            latestInDust.value = "실내 초미세먼지 데이터 수신 중"
                        }
                    }
                } else {
                    latestInDust.value = "서버 응답 실패: ${response.code()}"
                }
            }
            override fun onFailure(call: Call<IDUltraFineDustResponse>, t: Throwable) {    // 서버 요청 실패
                latestInDust.value = "Network Error"
                Log.e("windowViewModel", "")
            }
        })
    }

    fun loadLatestTemp() {    // 서버에서 최신 온도 데이터를 가져와
        val tempStatus = WINDOW.service.requestTemp(page=1)    // 서버에 온도 데이터 요청

        tempStatus.enqueue(object : Callback<Temperature> {     // enqueue로 응답 처리
            override fun onResponse(call: Call<Temperature>, response: Response<Temperature>) {
                if (response.isSuccessful) {      // 서버 응답이 성공적인지 확인
                    val temperatureData = response.body()    // 서버에서 받은 온도 데이터를 가져와
                    temperatureData?.let { data ->
                        data.results.firstOrNull()?.let { result ->
                            latestTemp.value = result.value.toString()    // 온도 데이터가 있으면 값 할당
                        } ?: run {
                            latestTemp.value = "온도 데이터 수신 중"    // 온도 데이터가 없을때
                        }
                    }
                } else {
                    latestTemp.value = "서버 응답 실패: ${response.code()}"
                }
            }
            override fun onFailure(call: Call<Temperature>, t: Throwable) {    // 서버 요청 실패
                latestTemp.value = "Network Error"
                Log.e("windowViewModel", "")
            }
        })
    }

    fun loadRainStatus() {
        val statusCall = WINDOW.service.rainStatus()

        statusCall.enqueue(object : Callback<RainStatusResponse> {
            override fun onResponse(call: Call<RainStatusResponse>, response: Response<RainStatusResponse>) {
                if(response.isSuccessful) {
                    val rainstatus = response.body()?.results?.firstOrNull()
                    isRaining.value = rainstatus?.control ?: false
                } else {
                    isRaining.value = false
                }
            }
            override fun onFailure(call: Call<RainStatusResponse>, t: Throwable) {
                isRaining.value = false
            }
        })
    }

    fun loadWindowStatus() {
        val statusCall = WINDOW.service.windowStatus()

        statusCall.enqueue(object : Callback<WindowStatusResponse> {
            override fun onResponse(call: Call<WindowStatusResponse>, response: Response<WindowStatusResponse>) {
                if(response.isSuccessful) {
                    val windowcontrol = response.body()?.results?.firstOrNull()
                    isWindowOpen.value = windowcontrol?.control ?: false
                } else {
                    isWindowOpen.value = false
                }
            }
            override fun onFailure(call: Call<WindowStatusResponse>, t: Throwable) {
                isWindowOpen.value = false
            }
        })
    }

    fun controlWindow(isOpen: Boolean) {
        val control = WindowStatus(isOpen)
        val controlCall = WINDOW.service.controlWindow(control)

        controlCall.enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                if (response.isSuccessful) {
                    Log.d("WindowFragment", "창문 상태 업로드 성공")
                } else {
                    Log.e("WindowFragment", "창문 상태 업로드 실패")
                }
            }
            override fun onFailure(call: Call<Void>, t: Throwable) {
                Log.e("WindowFragment", "네트워크 오류")
            }
        })
    }

    fun sendSttResult(sttResult: SttResult) {
        val windowService = WINDOW.service
        val call = windowService.sendSttResult(sttResult)

        call.enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                if (response.isSuccessful) {
                    Log.d("WindowFragment", "POST 요청 성공")
                } else {
                    Log.e("WindowFragment", "POST 요청 실패")
                }
            }
            override fun onFailure(call: Call<Void>, t: Throwable) {
                Log.e("WindowFragment", "네트워크 오류")
            }
        })
    }
}