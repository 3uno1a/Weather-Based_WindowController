package com.example.windows23.ui.window

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import android.Manifest
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.windows23.R
import com.example.windows23.databinding.FragmentWindowBinding
import com.example.windows23.ui.window.data.SttResult
import com.example.windows23.ui.window.data.WindowStatus
import com.example.windows23.ui.window.service.WINDOW
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.time.LocalDateTime
import java.util.Calendar

class WindowFragment: Fragment() {
    private var _binding: FragmentWindowBinding? = null
    private val mbinding get() = _binding!!

    val PERMISSION = 1
    private var isWindowOpen : Boolean = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentWindowBinding.inflate(inflater, container, false)
        val root: View = mbinding.root

        // 퍼미션 체크
        if (Build.VERSION.SDK_INT >= 23) {
            ActivityCompat.requestPermissions(requireActivity(), arrayOf(
                Manifest.permission.INTERNET,
                Manifest.permission.RECORD_AUDIO
            ), PERMISSION)
        }

        val textView = mbinding.sttResult
        val sttBtn = mbinding.recordBtn

        // RecognizerIntent 객체 생성 및 초기화
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)   // 음성인식을 수행 --> 인식 결과 반환
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, requireActivity().packageName)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR")   // 인식 언어 지정

        // RecognitionListener 객체는 음성 인식 결과를 처리하기 위한 콜백 메서드 구현
        val listener = object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle) {   // 음성인식 시작되기 전에 호출
                Toast.makeText(requireContext(), "음성인식을 시작합니다.", Toast.LENGTH_SHORT).show()
            }

            override fun onBeginningOfSpeech() {}  // 음성인식이 시작되었을 때

            override fun onRmsChanged(rmsdB: Float) {}   // 음성의 강도, 크기를 추적하거나 표시 (음성의 현재 RMS 값을 전달받아)

            override fun onBufferReceived(buffer: ByteArray) {}  // 음성 입력 데이터의 일부 또는 전체를 전달받아

            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                val message: String = when (error) {
                    SpeechRecognizer.ERROR_AUDIO -> "오디오 에러"
                    SpeechRecognizer.ERROR_CLIENT -> "클라이언트 에러"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "퍼미션 없음"
                    SpeechRecognizer.ERROR_NETWORK -> "네트워크 에러"
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "네트웍 타임아웃"
                    SpeechRecognizer.ERROR_NO_MATCH -> "찾을 수 없음"
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "RECOGNIZER가 바쁨"
                    SpeechRecognizer.ERROR_SERVER -> "서버가 이상함"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "말하는 시간초과"
                    else -> "알 수 없는 오류임"
                }
                Toast.makeText(requireContext(), "에러가 발생하였습니다. : $message", Toast.LENGTH_SHORT)
                    .show()
            }

            @RequiresApi(Build.VERSION_CODES.O)
            override fun onResults(results: Bundle) {
                val windowViewModel: WindowViewModel by viewModels()
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val spokenText = matches[0]     // 가장 최신 음성인식 저장
                    textView.text = spokenText

                    val sttResult = SttResult(id = 0, text = spokenText, date = LocalDateTime.now().toString())
                    windowViewModel.sendSttResult(sttResult)

                    when {
                        spokenText.contains("창문 열어 줘") -> {
                            updateWindowUI(true)
                            windowViewModel.controlWindow(true)
                        }
                        spokenText.contains("창문 닫아 줘") -> {
                            updateWindowUI(false)
                            windowViewModel.controlWindow(false)
                        } else -> {
                            Log.e("WindowFragment", "네트워크 오류")
                        }
                    }
                }
            }

            override fun onPartialResults(partialResults: Bundle) {}  // 음성 인식 중 부분적으로 인식된 결과가 있을 때

            override fun onEvent(eventType: Int, params: Bundle) {}  // 음성인식 과정에서 발생하는 상태 변경 등에 사용
        }

        // 객체에 Context와 listener를 할당한 후 실행
        sttBtn.setOnClickListener {
            val recognizer = SpeechRecognizer.createSpeechRecognizer(requireContext())   // SpeechRecognizer 객체 생성
            recognizer.setRecognitionListener(listener)
            recognizer.startListening(intent)   // 음성인식 시작 --> 결과 반환
        }
        return root
    }


    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val windowViewModel: WindowViewModel by viewModels()     // windowViewModel 불러오기

        windowViewModel.getLatestInDust().observe(viewLifecycleOwner) { value ->
            val formattedValue = value?.toDoubleOrNull()?.toInt( )?: 0     // 소수점을 제거하고 정수로 변환
            mbinding.currentIdUltradust.text = formattedValue.toString()

            if (formattedValue < 30) {
                mbinding.idUltraGrade.setImageResource(R.drawable.circle)
            } else if (formattedValue in 30..80) {
                mbinding.idUltraGrade.setImageResource(R.drawable.yellow_circle)
            } else {
                mbinding.idUltraGrade.setImageResource(R.drawable.red_circle)
            }
        }

        windowViewModel.getLatestOutDust().observe(viewLifecycleOwner) { value ->
            val formattedValue = value?.toDoubleOrNull()?.toInt() ?: 0       // 소수점을 제거하고 정수로 변환
            mbinding.currentOdUltrafindust.text = formattedValue.toString()

            if (formattedValue < 30) {
                mbinding.odUltraGrade.setImageResource(R.drawable.circle)
            } else if (formattedValue in 30..80) {
                mbinding.odUltraGrade.setImageResource(R.drawable.yellow_circle)
            } else {
                mbinding.odUltraGrade.setImageResource(R.drawable.red_circle)
            }
        }

        windowViewModel.getLatestTemp().observe(viewLifecycleOwner) {
            mbinding.currentTemp.text = it
        }

        windowViewModel.getRainStatus().observe(viewLifecycleOwner) { isRain ->
            if (isRain) {
                mbinding.currentRain.text = "Yes"
            }
            else  {
                mbinding.currentRain.text = "No"
                mbinding.imageView2.setImageResource(R.drawable.sun)
            }
        }

        windowViewModel.getWindowStatus().observe(viewLifecycleOwner) { isWindowOpen ->
            updateWindowUI(isWindowOpen)
        }

        mbinding.btnWindow.setOnClickListener {
            isWindowOpen = !isWindowOpen
            updateWindowUI(isWindowOpen)
            windowViewModel.controlWindow(isWindowOpen)
            true
        }

        windowViewModel.loadLatestOutDust()
        windowViewModel.loadLatestInDust()
        windowViewModel.loadLatestTemp()
        windowViewModel.loadRainStatus()
        windowViewModel.loadWindowStatus()
    }

    private fun updateWindowUI(isWindowOpen: Boolean) {
        val currentTime = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (isWindowOpen) {
            mbinding.currentWindowstatus.text = "Open"
            mbinding.btnWindow.setImageResource(R.drawable.close)     // 창문 제어 버튼 닫힘으로 변경
            if (currentTime in 6..17) {
                mbinding.imageView6.setImageResource(R.drawable.window_open1)
            } else {
                mbinding.imageView6.setImageResource(R.drawable.window_open2)
            }
        } else {    // 창문 닫힌 상태
            mbinding.currentWindowstatus.text = "Close"
            mbinding.imageView6.setImageResource(R.drawable.window_close)
            mbinding.btnWindow.setImageResource(R.drawable.open)     // 창문 제어 버튼 열림으로 변경
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null      // 바인딩 자체를 메모리에서 null로 날려
    }
}