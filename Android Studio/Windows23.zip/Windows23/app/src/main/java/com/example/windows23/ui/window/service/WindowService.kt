package com.example.windows23.ui.window.service

import com.example.windows23.ui.window.data.IDUltraFineDustResponse
import com.example.windows23.ui.window.data.ODUltraFineDustResponse
import com.example.windows23.ui.window.data.RainStatusResponse
import com.example.windows23.ui.window.data.SttResult
import com.example.windows23.ui.window.data.Temperature
import com.example.windows23.ui.window.data.WindowStatus
import com.example.windows23.ui.window.data.WindowStatusResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface WindowService {
    @GET("/api/outdoor_ultrafine/")
    fun requestODUltraFine(@Query("page") page: Int): Call<ODUltraFineDustResponse>

    @GET("/api/indoor_ultrafine/")
    fun requestIDUltraFine(@Query("page") page: Int): Call<IDUltraFineDustResponse>

    @GET("/api/temp/")
    fun requestTemp(@Query("page") page: Int): Call<Temperature>

    @GET("/api/rain/")
    fun rainStatus() : Call<RainStatusResponse>

    @GET("/api/window/")
    fun windowStatus() : Call<WindowStatusResponse>

    @POST("/api/window/")       // 앱에서 제어한 control 상태를 API 서버에 업로드
    fun controlWindow(@Body control: WindowStatus): Call<Void>

    @POST("/api/speech/")
    fun sendSttResult(@Body control: SttResult): Call<Void>
}