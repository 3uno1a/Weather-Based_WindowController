package com.example.windows23.ui.window.service

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object WINDOW {  // 객체
    // Http 통신에서 일어나는 에러들을 자세히 알려줌
    private val logging = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY   
    }

    private val client = OkHttpClient.Builder().apply {
        addInterceptor(logging)        
    }.build()

    private val retrofit = Retrofit.Builder()    // retrofit 인스턴스 생성
        .baseUrl("http://192.168.35.245:8000/")
        .addConverterFactory(GsonConverterFactory.create())
        .client(client)
        .build()

    val service get() = retrofit.create(WindowService::class.java)
}